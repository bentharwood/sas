<footer>
  &copy; <?php echo date('Y'); ?> Globe Bank
</footer>

</div>

<?php DB_disconnect($db) ?>
</body>
</html>
