<?php require_once('..\private/initialize.php'); ?>

<?php 
$page_title = 'Home';
include(SHARED_PATH .'\staff_header.php'); 
?>

    <h1>Globe Bank: Coming Soon</h1>

<?php 
  include(SHARED_PATH . '\staff_footer.php');
?>
